﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace LogMonitorApplication
{
    public class CountUpdate
    {
        private StreamWriter sw1;
        private int id;
        private string FolderLocation;
        private string ProjectName;
        private InitialisationClass dbConn;
        private int TotalWords;

        public CountUpdate(string title, int ID, int totalWords)
        {
            ProjectName = title;
            id = ID;
            dbConn = new InitialisationClass();
            dbConn.init();
            TotalWords = totalWords;
        }

        public void CreateFileFolder(string homelocation)
        {
            FolderLocation = homelocation + "\\" + ProjectName;
            if (!Directory.Exists(FolderLocation))
            {
                DirectoryInfo di = Directory.CreateDirectory(FolderLocation);
            }
            string filepath = FolderLocation + "\\" + ProjectName + "_" + id + ".txt";
            sw1 = new StreamWriter(filepath);
            sw1.AutoFlush = true;
        }

        public void FileAppend(string sline, string sWord, string sfname, int lineNo, int CountNo)
        {
            if (CountNo == 0)
            {
                sw1.WriteLine("\n" + "***************************" + sWord + "***************************");
                sw1.WriteLine("***************************" + sfname + "***************************" + "\n");
            }
            sw1.WriteLine(lineNo + " : " + sline);
        }

        public void InsertQuery(string keyword, int count, int filesRead)
        {
            SqlConnection con = dbConn.getDBOject();
            try
            {
                List<string> idPresent=new List<string>();
                con.Open();
                string query = "select SearchID from CountHistory where SearchID = '" + id + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader r1 = cmd.ExecuteReader();
                try
                {
                    while (r1.Read())
                    {
                        idPresent.Add(r1["SearchID"].ToString());
                    }
                }
                finally
                {
                    r1.Close();
                    cmd.Dispose();
                }
                if (idPresent.Count < TotalWords)
                {
                    query = "insert into CountHistory values ('" + id + "', '" + keyword + "', '" + count + "', '" + filesRead + "')";
                    cmd = new SqlCommand(query, con);
                    int i = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                }
            }
            catch(Exception e)
            {
                System.Windows.Forms.MessageBox.Show("Error is :\n" + e);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
