﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;

namespace LogMonitorApplication
{
    public class InitialisationClass
    {
        private string sServerName;
        private string sDBName;
        private string sHomeLocation;

        SqlConnection scConn;
        public InitialisationClass()
        {
            ReadConfig();
        }

        public void init()
        {
            sHomeLocation = sHomeLocation + "\\LogMonitor";
            if (!Directory.Exists(sHomeLocation))
            {
                DirectoryInfo di = Directory.CreateDirectory(sHomeLocation);
            }
            createDbConn(); 
        }

        public string getHomeLocation()
        {
            return sHomeLocation;
        }
        public void ReadConfig()
        {
         
            string[] details = new string[3];
            string path = Directory.GetCurrentDirectory();
            System.IO.DirectoryInfo directoryInfo = System.IO.Directory.GetParent(path);
            directoryInfo = System.IO.Directory.GetParent(directoryInfo.FullName);
            path = directoryInfo.FullName + "\\Config\\param.ini";
            StreamReader sr = new StreamReader(path);
            string str = sr.ReadLine();
            int i = 0;
            while(str != null)
            {
                string words = Regex.Replace(str, @"\s+", "");
                string[] word = words.Split('=');
                details[i] = word[1];
                str = sr.ReadLine();
                i++;
            }
            sServerName = details[0];
            sDBName = details[1];
            sHomeLocation = details[2];
        }
        public void createDbConn()
        {
            string connstring = "Data Source=" + sServerName + ";Initial Catalog=" + sDBName + "; Integrated Security=True";
            scConn = new SqlConnection(connstring);
        }

        public SqlConnection getDBOject()
        {
            return scConn;
        }
    }
}
