﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;
using System.Data.SqlClient;

namespace LogMonitorApplication
{
    public partial class FolderAccess
    {
        private int cnt1;
        private int NoFilesPresent;
        private int NoFilesRead;

        public int CountHistoryCheck()
        {
            SqlConnection con = dbConn.getDBOject();
            try
            {
                con.Open();
                int count = 0;
                string s = "select COUNT(SearchID) from CountHistory where SearchID = '" + id + "'";
                SqlCommand cmd = new SqlCommand(s, con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        count = Int32.Parse(dr[0].ToString());
                    }
                }
                cmd.Dispose();
                return count;
            }
            catch (Exception)
            {
                return -1;
            }
            finally
            {
                con.Close();
            }
        }

        public void FetchCountHistory()
        {
            SqlConnection con = dbConn.getDBOject();
            try
            {
                con.Open();
                string s = "select Count,FilesRead from CountHistory where SearchID = '" + id + "'";
                SqlCommand cmd = new SqlCommand(s, con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        counter.Add(Int32.Parse(dr[0].ToString()));
                        NoFilesRead = Int32.Parse(dr[1].ToString());
                    }
                }
                cmd.Dispose();
            }
            finally
            {
                con.Close();
            }
        }

        public int FolderRead(ref string errMsg)
        {
            try
            {
                int j;
                DateTime dt;
                string[] files = Directory.GetFiles(LogLocation);
                NoFilesPresent = files.Length;
                NoFilesRead = 0;
                int CountCheck = CountHistoryCheck();
                if (CountCheck == 0)
                {
                    CountUpdate cu = new CountUpdate(Title, id, keywords.Count);
                    cu.CreateFileFolder(HomeLocation);
                    for (int i = 0; i < NoFilesPresent; i++)
                    {
                        j = 0;
                        dt = File.GetLastWriteTime(files[i]);
                        if (dt >= startTime && dt <= endTime)
                        {
                            foreach (var word in keywords)
                            {
                                if (counter.Count <= keywords.Count && NoFilesRead == 0)
                                    counter.Add(WordCount(word, files[i], ref cu));
                                else
                                    counter[j] += WordCount(word, files[i], ref cu);
                                j++;
                            }
                            NoFilesRead++;
                        }
                    }
                    if (NoFilesRead == 0)
                    {
                        for (int i = 0; i < keywords.Count; i++)
                            counter.Add(0);
                    }
                    for (int i = 0; i < keywords.Count; i++)
                    {
                        cu.InsertQuery(keywords[i], counter[i], NoFilesRead);
                    }
                }
                else if (CountCheck > 0)
                {
                    FetchCountHistory();
                }
                return 0;
            }
            catch(Exception e)
            {
                errMsg = "Error is : \n" + e;
                return 1;
            }
            
        }

        public int WordCount(string word,string fname, ref CountUpdate cu)
        {
            cnt1 = 0;
            int match = 0;
            int LineNo = 1;
            int CountNo = 0;
            StreamReader sr = new StreamReader(fname);
            sr.BaseStream.Seek(0, SeekOrigin.Begin);
            string str = sr.ReadLine();
            while (str != null)
            {
                match = Regex.Matches(str, word,RegexOptions.IgnoreCase).Count;
                if (match != 0)
                {
                    cnt1 = cnt1 + match;
                    cu.FileAppend(str, word, fname, LineNo, CountNo);
                    CountNo++;
                }
                str = sr.ReadLine();
                LineNo++;
            }
            sr.Close();
            return cnt1;
        }

        public int GetFilesPresent()
        {
            return NoFilesPresent;
        }

        public int GetFilesRead()
        {
            return NoFilesRead;
        }
    }
}