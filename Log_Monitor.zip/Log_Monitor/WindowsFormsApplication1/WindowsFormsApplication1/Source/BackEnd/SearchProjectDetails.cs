﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;

namespace LogMonitorApplication
{
    public class SearchProjectDetails
    {
        private InitialisationClass dbConn;
        private string loglocation;
        private string title;
        private int id;

        public SearchProjectDetails(string name, ref InitialisationClass intiObj)
        {
            dbConn = intiObj;
            title = name;
        }

        public List<List<string>> RecordsDisplay()
        {
            SqlConnection con = dbConn.getDBOject();
            List<List<string>> SearchHistoryRecords = new List<List<string>>();
            try
            {
                con.Open();
                string s = "select SearchID,ProjectTitle,StartTime,EndTime from SearchHistory where ProjectTitle = '" + title + "'";
                SqlCommand cmd = new SqlCommand(s, con);
                SqlDataReader r1 = cmd.ExecuteReader();
                try
                {
                    while (r1.Read())
                    {
                        SearchHistoryRecords.Add(new List<string> { r1["SearchID"].ToString(), r1["ProjectTitle"].ToString(), r1["StartTime"].ToString(), r1["EndTime"].ToString() });
                    }
                }
                finally
                {
                    r1.Close();
                }
                
            }
            finally
            {
                con.Close();
            }
            return SearchHistoryRecords;
        }

        public int InsertSearch(DateTime start, DateTime end, ref string errMsg)
        {
            SqlConnection con = dbConn.getDBOject();
            try
            {
                con.Open();
                DateTime st = new DateTime(start.Year, start.Month, start.Day, start.Hour, start.Minute, start.Second);
                DateTime et = new DateTime(end.Year, end.Month, end.Day, end.Hour, end.Minute, end.Second);
                SqlCommand cmd = new SqlCommand("insert into SearchHistory values ('" + title + "','" + st.ToString("MM-dd-yyyy HH:mm:ss") + "','" + et.ToString("MM-dd-yyyy HH:mm:ss") + "')", con);
                int i = cmd.ExecuteNonQuery();
                cmd.Dispose();
                string s = "select MAX(SearchID) from SearchHistory";
                cmd = new SqlCommand(s,con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        id = Int32.Parse(dr[0].ToString());
                    }
                }
                return 0;
            }
            catch(Exception e)
            {
                errMsg = "Error : " + e;
                return 1;
            }
            finally
            {
                con.Close();
            }
        }

        public int GetDetails(ref string errMsg)
        {
            SqlConnection con = dbConn.getDBOject();
            try
            {
                con.Open();
                string s = "select LogLocation from Projects where Title = '" + title + "'";
                SqlCommand cmd = new SqlCommand(s, con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        loglocation = dr[0].ToString();
                    }
                }
                cmd.Dispose();
                return 0;
            }
            catch(Exception e)
            {
                errMsg = "Error : " + e;
                return 1;
            }
            finally
            {
                con.Close();
            }
        }

        public void FileCheck(string location)
        {
            string[] files = Directory.GetFiles(location);
            foreach (var file in files)
            {
                StreamReader sr = new StreamReader(file);
            }
        }

        public string GetLogLocation()
        {
            return loglocation;
        }

        public string GetTitle()
        {
            return title;
        }

        public int getID()
        {
            return id;
        }
    }
}
