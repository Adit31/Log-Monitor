﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace LogMonitorApplication
{
    public partial class FolderAccess
    {
        private InitialisationClass dbConn;
        private string HomeLocation;
        private string LogLocation;
        private string Title;
        private int id;
        private DateTime startTime;
        private DateTime endTime;
        public List<string> keywords;
        public List<int> counter;

        public FolderAccess(string sLogLocation, int ID, string stitle)
        {
            LogLocation = sLogLocation;
            id = ID;
            Title = stitle;
            keywords = new List<string>();
            counter = new List<int>();
            dbConn = new InitialisationClass();
            dbConn.init();
        }

        public int RunQuery(ref string errMsg)
        {
            string words = "";
            SqlConnection con = dbConn.getDBOject();
            HomeLocation = dbConn.getHomeLocation();
            try
            {
                con.Open();
                string query = "select * from SearchHistory where SearchID = '" + id + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        startTime = Convert.ToDateTime(dr[2]);
                        endTime = Convert.ToDateTime(dr[3]);
                    }
                }
                cmd.Dispose();
                query = "select Keywords from Projects,SearchHistory where SearchID = '" + id + "' and Title = ProjectTitle";
                SqlCommand cmd1 = new SqlCommand(query, con);
                using (SqlDataReader dr = cmd1.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        words = dr[0].ToString();
                    }
                }
                words = Regex.Replace(words, @"\s+", "");
                string[] word = words.Split(',');
                for (int i = 0; i < 6; i++) 
                {
                    if (i < word.Length)
                        keywords.Add(word[i]);
                }
                cmd1.Dispose();
                return 0;
            }
            catch(Exception e)
            {
                errMsg = "Error is : " + e;
                return 1;
            }
            finally
            {
                con.Close();
            }
        }

        public string getHomeLocation()
        {
            return HomeLocation;
        }
    }
}
