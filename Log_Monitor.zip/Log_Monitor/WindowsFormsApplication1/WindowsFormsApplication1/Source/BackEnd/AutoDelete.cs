﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.SqlClient;

namespace LogMonitorApplication
{
    class AutoDelete
    {
        private InitialisationClass initObj;
        private string homelocation;
        private int FileAge;
        private int SearchID;

        public AutoDelete()
        {
            initObj = new InitialisationClass();
            initObj.init();
            homelocation = initObj.getHomeLocation();
            FileAge = 30;
            SearchID = 0;
            GetFiles();
        }

        public int CheckDate(DateTime FileCreateTime)
        {
            DateTime CurrentTime = DateTime.Now;
            if ((CurrentTime - FileCreateTime).TotalDays > FileAge)
                return 1;
            else
                return 0;
        }

        public void GetFiles()
        {
            string[] subdirs = Directory.GetDirectories(homelocation);

            foreach (var folders in subdirs)
            {
                DirectoryInfo d = new DirectoryInfo(folders);
                FileInfo[] Files = d.GetFiles();
                foreach (FileInfo file in Files)
                {
                    if (CheckDate(file.CreationTime) == 1)
                    {
                        string GetID = file.Name.Substring(file.Name.IndexOf("_") + 1);
                        GetID = GetID.Substring(0, GetID.IndexOf("."));
                        SearchID = Int32.Parse(GetID);
                        File.Delete(file.FullName);
                    }
                }
            }
            AutoDeleteTableRecord();
        }

        public void AutoDeleteTableRecord()
        {
            SqlConnection con = initObj.getDBOject();
            try
            {
                con.Open();
                string s = "delete from SearchHistory where SearchID = '"+ SearchID +"'";
                SqlCommand cmd = new SqlCommand(s, con);
                int i = cmd.ExecuteNonQuery();
                cmd.Dispose();
                s = "delete from CountHistory where SearchID = '"+ SearchID +"'";
                cmd = new SqlCommand(s,con);
                i = cmd.ExecuteNonQuery();
                cmd.Dispose();
            }
            finally
            {
                con.Close();
            }
        }
    }
}
