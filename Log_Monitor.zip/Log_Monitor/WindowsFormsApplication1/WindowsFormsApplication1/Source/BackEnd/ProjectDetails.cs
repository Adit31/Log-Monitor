﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Remoting.Messaging;

namespace LogMonitorApplication
{
    public class ProjectDetails
    {
        Dictionary<int, string> projectlist;
        InitialisationClass initObj;

        public ProjectDetails()
        {

            initObj = new InitialisationClass();
            initObj.init();
        }
        public int createProjectList(ref string errMsg)
        {
            projectlist = new Dictionary<int, string>();
            SqlConnection con = initObj.getDBOject();
            try
            {
                con.Open();
                string s = "select ID,Title from Projects where status = 1";
                SqlCommand cmd = new SqlCommand(s, con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        projectlist.Add(Int32.Parse(dr[0].ToString()), dr[1].ToString());
                    }
                }
                cmd.Dispose();
                return 0;
            }
            catch (Exception e)
            {
                errMsg = "DataBase Error, try after sometime";
                return 1;
            }
            finally
            {
                con.Close();
            }
        }

        public Dictionary<int, string> GetTitleList()
        {
            return projectlist;
        }

        public int createNewProject(string stitle, string sloglocation, string skeyword, ref string errMsg)
        {
            // create new project obj
            //projectobj .createnewproject
            SqlConnection con = initObj.getDBOject();
            string homelocation = initObj.getHomeLocation();
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("insert into Projects values ('" + stitle + "','" + sloglocation + "','" + homelocation + "','" + skeyword + "',1)", con);
                int i = cmd.ExecuteNonQuery();
                cmd.Dispose();
                string s = "select ID,Title from Projects where title = '" + stitle + "'";
                cmd = new SqlCommand(s, con);
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        projectlist.Add(Int32.Parse(dr[0].ToString()), dr[1].ToString());
                    }
                }
                cmd.Dispose();
                return 0;
            }
            catch(System.Data.SqlClient.SqlException)
            {
                errMsg = "Project Title already exists";
                return 1;
            }
            catch(Exception e)
            {
                errMsg = "Error is : " + e;
                return 1;
            }
            finally
            {
                con.Close();
            }
        }

        public SearchProjectDetails getProject(string name)
        {
             SearchProjectDetails proObj  =  new SearchProjectDetails(name, ref initObj);
             return proObj;
        }

        public int DeleteRecord(string title, ref string errMsg)
        {
            SqlConnection con = initObj.getDBOject();
            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("delete from Projects where Title = '" + title + "'", con);
                int i = cmd.ExecuteNonQuery();
                cmd.Dispose();
                return i;
            }
            catch (Exception e)
            {
                errMsg = "Error : " + e;
                return -1;
            }
            finally
            {
                con.Close();
            }
        }

    }
}
