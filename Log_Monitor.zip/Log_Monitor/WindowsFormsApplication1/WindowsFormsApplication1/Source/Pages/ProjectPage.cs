﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LogMonitorApplication
{
    public partial class ProjectPage : Form
    {
        Form parent;
        private SearchProjectDetails spd;
        private List<List<string>> Records;
        public string SelectedProjectTitle;
        public ProjectPage(Form Parent_form, ref SearchProjectDetails proobj)
        {
            parent = Parent_form;
            SelectedProjectTitle = proobj.GetTitle();
            InitializeComponent();
            spd = proobj;
        }

        private void logform_Load(object sender, EventArgs e)
        {
            Records = spd.RecordsDisplay();
            foreach (var record in Records)
            {
                SearchHistoryTable.Rows.Add(record[0], record[1], record[2], record[3]);
            }
            DispTitleLabel.Text = SelectedProjectTitle;
            string errMsg = "";
            int res = spd.GetDetails(ref errMsg);
            if (res == 0)
            {
                DispLogLocationLabel.Text = spd.GetLogLocation();
            }
            else
            {
                System.Windows.Forms.MessageBox.Show(errMsg);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            parent.Visible = true;
            this.Close();
        }

        private void EnterButton_Click(object sender, EventArgs e)
        {
            string errMsg = "";
            if (StartTimePicker.Value < EndTimePicker.Value)
            {
                try
                {
                    spd.FileCheck(DispLogLocationLabel.Text);
                    int res = spd.InsertSearch(StartTimePicker.Value, EndTimePicker.Value, ref errMsg);
                    if (res == 0)
                    {
                        int id = spd.getID();
                        ResultPage r1 = new ResultPage(this, DispLogLocationLabel.Text, DispTitleLabel.Text);
                        r1.SetId(id);
                        r1.Show();
                        this.Visible = false;
                        SearchHistoryTable.Rows.Add(id, DispTitleLabel.Text, StartTimePicker.Value, EndTimePicker.Value);
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show(errMsg);
                    }
                }
                catch(System.IO.IOException)
                {
                    System.Windows.Forms.MessageBox.Show("Unable to Access some Files from the Specified Folder");
                }
            }
            else
                System.Windows.Forms.MessageBox.Show("Start Time should be Less than End Time");
        }

        private void EnterButton1_Click(object sender, EventArgs e)
        {
            ResultPage r1 = new ResultPage(this, DispLogLocationLabel.Text, DispTitleLabel.Text);
            if (SearchIDBox.Text == "")
            {
                System.Windows.Forms.MessageBox.Show("Null Value not Valid");
            }
            else
            {
                try
                {
                    r1.SetId(Int32.Parse(SearchIDBox.Text));
                    int flag = 0;
                    Records = spd.RecordsDisplay();
                    foreach(var record in Records)
                    {
                        if(record[0]==SearchIDBox.Text)
                        {
                            flag = 1;
                            break;
                        }
                    }
                    if (flag == 1)
                    { 
                        r1.Show();
                        this.Visible = false;
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Enter ID from Above Only");
                    }
                }
                catch (System.FormatException)
                {
                    System.Windows.Forms.MessageBox.Show("Enter Numeric Values Only");
                }
                catch (System.ArgumentOutOfRangeException)
                {
                    System.Windows.Forms.MessageBox.Show("Perform a Valid Search First");
                }
                catch(Exception)
                {
                    System.Windows.Forms.MessageBox.Show("Error in Execution");
                }
            }
        }

        private void ClearButton2_Click(object sender, EventArgs e)
        {
            SearchIDBox.Clear();
        }

        private void SearchHistoryTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DispLocationBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void DispTitleBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void DispTitleLabel_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}