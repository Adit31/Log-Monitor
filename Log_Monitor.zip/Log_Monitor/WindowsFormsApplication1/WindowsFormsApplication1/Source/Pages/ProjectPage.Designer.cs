﻿namespace LogMonitorApplication
{
    partial class ProjectPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectPage));
            this.BackButton = new System.Windows.Forms.Button();
            this.DispTitleLabel = new System.Windows.Forms.Label();
            this.DispLogLocationLabel = new System.Windows.Forms.Label();
            this.PreviousLabel = new System.Windows.Forms.Label();
            this.SearchHistoryTable = new System.Windows.Forms.DataGridView();
            this.SearchID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EndTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SearchIDLabel = new System.Windows.Forms.Label();
            this.SearchIDBox = new System.Windows.Forms.TextBox();
            this.StartTimePicker = new System.Windows.Forms.DateTimePicker();
            this.OrLabel = new System.Windows.Forms.Label();
            this.EndTimePicker = new System.Windows.Forms.DateTimePicker();
            this.StartTimeLabel = new System.Windows.Forms.Label();
            this.EndTimeLabel = new System.Windows.Forms.Label();
            this.ClearButton2 = new System.Windows.Forms.Button();
            this.EnterButton = new System.Windows.Forms.Button();
            this.EnterButton1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.SearchHistoryTable)).BeginInit();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.Red;
            this.BackButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackButton.BackgroundImage")));
            this.BackButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BackButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackButton.Location = new System.Drawing.Point(30, 644);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(90, 27);
            this.BackButton.TabIndex = 0;
            this.BackButton.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // DispTitleLabel
            // 
            this.DispTitleLabel.AutoSize = true;
            this.DispTitleLabel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DispTitleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DispTitleLabel.Location = new System.Drawing.Point(12, 9);
            this.DispTitleLabel.Name = "DispTitleLabel";
            this.DispTitleLabel.Size = new System.Drawing.Size(96, 25);
            this.DispTitleLabel.TabIndex = 6;
            this.DispTitleLabel.Text = "Title Here";
            this.DispTitleLabel.Click += new System.EventHandler(this.DispTitleLabel_Click);
            // 
            // DispLogLocationLabel
            // 
            this.DispLogLocationLabel.AutoSize = true;
            this.DispLogLocationLabel.Location = new System.Drawing.Point(12, 44);
            this.DispLogLocationLabel.Name = "DispLogLocationLabel";
            this.DispLogLocationLabel.Size = new System.Drawing.Size(141, 20);
            this.DispLogLocationLabel.TabIndex = 8;
            this.DispLogLocationLabel.Text = " Log Location here";
            // 
            // PreviousLabel
            // 
            this.PreviousLabel.AutoSize = true;
            this.PreviousLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PreviousLabel.Location = new System.Drawing.Point(361, 82);
            this.PreviousLabel.Name = "PreviousLabel";
            this.PreviousLabel.Size = new System.Drawing.Size(249, 22);
            this.PreviousLabel.TabIndex = 9;
            this.PreviousLabel.Text = "Previous Searches Performed";
            // 
            // SearchHistoryTable
            // 
            this.SearchHistoryTable.AllowUserToAddRows = false;
            this.SearchHistoryTable.AllowUserToDeleteRows = false;
            this.SearchHistoryTable.AllowUserToResizeColumns = false;
            this.SearchHistoryTable.AllowUserToResizeRows = false;
            this.SearchHistoryTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SearchHistoryTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SearchID,
            this.ProjectTitle,
            this.StartTime,
            this.EndTime});
            this.SearchHistoryTable.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.SearchHistoryTable.Location = new System.Drawing.Point(138, 127);
            this.SearchHistoryTable.Name = "SearchHistoryTable";
            this.SearchHistoryTable.RowHeadersWidth = 62;
            this.SearchHistoryTable.RowTemplate.Height = 28;
            this.SearchHistoryTable.Size = new System.Drawing.Size(695, 150);
            this.SearchHistoryTable.TabIndex = 10;
            this.SearchHistoryTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SearchHistoryTable_CellContentClick);
            // 
            // SearchID
            // 
            this.SearchID.HeaderText = "SearchID";
            this.SearchID.MinimumWidth = 8;
            this.SearchID.Name = "SearchID";
            this.SearchID.Width = 150;
            // 
            // ProjectTitle
            // 
            this.ProjectTitle.HeaderText = "ProjectTitle";
            this.ProjectTitle.MinimumWidth = 8;
            this.ProjectTitle.Name = "ProjectTitle";
            this.ProjectTitle.Width = 150;
            // 
            // StartTime
            // 
            this.StartTime.HeaderText = "StartTime";
            this.StartTime.MinimumWidth = 8;
            this.StartTime.Name = "StartTime";
            this.StartTime.Width = 150;
            // 
            // EndTime
            // 
            this.EndTime.HeaderText = "EndTime";
            this.EndTime.MinimumWidth = 8;
            this.EndTime.Name = "EndTime";
            this.EndTime.Width = 150;
            // 
            // SearchIDLabel
            // 
            this.SearchIDLabel.AutoSize = true;
            this.SearchIDLabel.Location = new System.Drawing.Point(269, 332);
            this.SearchIDLabel.Name = "SearchIDLabel";
            this.SearchIDLabel.Size = new System.Drawing.Size(207, 20);
            this.SearchIDLabel.TabIndex = 11;
            this.SearchIDLabel.Text = "Enter Search ID from above";
            // 
            // SearchIDBox
            // 
            this.SearchIDBox.Location = new System.Drawing.Point(510, 326);
            this.SearchIDBox.Name = "SearchIDBox";
            this.SearchIDBox.Size = new System.Drawing.Size(100, 26);
            this.SearchIDBox.TabIndex = 12;
            // 
            // StartTimePicker
            // 
            this.StartTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.StartTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.StartTimePicker.Location = new System.Drawing.Point(510, 438);
            this.StartTimePicker.Name = "StartTimePicker";
            this.StartTimePicker.Size = new System.Drawing.Size(218, 26);
            this.StartTimePicker.TabIndex = 13;
            this.StartTimePicker.Value = new System.DateTime(2020, 2, 18, 20, 30, 0, 0);
            // 
            // OrLabel
            // 
            this.OrLabel.AutoSize = true;
            this.OrLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrLabel.Location = new System.Drawing.Point(466, 385);
            this.OrLabel.Name = "OrLabel";
            this.OrLabel.Size = new System.Drawing.Size(41, 25);
            this.OrLabel.TabIndex = 14;
            this.OrLabel.Text = "OR";
            // 
            // EndTimePicker
            // 
            this.EndTimePicker.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.EndTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.EndTimePicker.Location = new System.Drawing.Point(510, 492);
            this.EndTimePicker.Name = "EndTimePicker";
            this.EndTimePicker.Size = new System.Drawing.Size(218, 26);
            this.EndTimePicker.TabIndex = 15;
            this.EndTimePicker.Value = new System.DateTime(2020, 2, 19, 0, 30, 0, 0);
            // 
            // StartTimeLabel
            // 
            this.StartTimeLabel.AutoSize = true;
            this.StartTimeLabel.Location = new System.Drawing.Point(281, 443);
            this.StartTimeLabel.Name = "StartTimeLabel";
            this.StartTimeLabel.Size = new System.Drawing.Size(195, 20);
            this.StartTimeLabel.TabIndex = 16;
            this.StartTimeLabel.Text = "Enter Start Date and Time";
            // 
            // EndTimeLabel
            // 
            this.EndTimeLabel.AutoSize = true;
            this.EndTimeLabel.Location = new System.Drawing.Point(287, 498);
            this.EndTimeLabel.Name = "EndTimeLabel";
            this.EndTimeLabel.Size = new System.Drawing.Size(189, 20);
            this.EndTimeLabel.TabIndex = 17;
            this.EndTimeLabel.Text = "Enter End Date and Time";
            // 
            // ClearButton2
            // 
            this.ClearButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ClearButton2.BackgroundImage")));
            this.ClearButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClearButton2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ClearButton2.Location = new System.Drawing.Point(510, 574);
            this.ClearButton2.Name = "ClearButton2";
            this.ClearButton2.Size = new System.Drawing.Size(99, 30);
            this.ClearButton2.TabIndex = 18;
            this.ClearButton2.UseVisualStyleBackColor = true;
            this.ClearButton2.Click += new System.EventHandler(this.ClearButton2_Click);
            // 
            // EnterButton
            // 
            this.EnterButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EnterButton.BackgroundImage")));
            this.EnterButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.EnterButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EnterButton.Location = new System.Drawing.Point(377, 574);
            this.EnterButton.Name = "EnterButton";
            this.EnterButton.Size = new System.Drawing.Size(99, 30);
            this.EnterButton.TabIndex = 19;
            this.EnterButton.UseVisualStyleBackColor = true;
            this.EnterButton.Click += new System.EventHandler(this.EnterButton_Click);
            // 
            // EnterButton1
            // 
            this.EnterButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EnterButton1.BackgroundImage")));
            this.EnterButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.EnterButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EnterButton1.Location = new System.Drawing.Point(647, 326);
            this.EnterButton1.Name = "EnterButton1";
            this.EnterButton1.Size = new System.Drawing.Size(81, 26);
            this.EnterButton1.TabIndex = 20;
            this.EnterButton1.UseVisualStyleBackColor = true;
            this.EnterButton1.Click += new System.EventHandler(this.EnterButton1_Click);
            // 
            // ProjectPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(968, 680);
            this.Controls.Add(this.EnterButton1);
            this.Controls.Add(this.EnterButton);
            this.Controls.Add(this.ClearButton2);
            this.Controls.Add(this.EndTimeLabel);
            this.Controls.Add(this.StartTimeLabel);
            this.Controls.Add(this.EndTimePicker);
            this.Controls.Add(this.OrLabel);
            this.Controls.Add(this.StartTimePicker);
            this.Controls.Add(this.SearchIDBox);
            this.Controls.Add(this.SearchIDLabel);
            this.Controls.Add(this.SearchHistoryTable);
            this.Controls.Add(this.PreviousLabel);
            this.Controls.Add(this.DispLogLocationLabel);
            this.Controls.Add(this.DispTitleLabel);
            this.Controls.Add(this.BackButton);
            this.Name = "ProjectPage";
            this.Text = "Project Details";
            this.Load += new System.EventHandler(this.logform_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SearchHistoryTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label DispTitleLabel;
        private System.Windows.Forms.Label DispLogLocationLabel;
        private System.Windows.Forms.Label PreviousLabel;
        private System.Windows.Forms.DataGridView SearchHistoryTable;
        private System.Windows.Forms.Label SearchIDLabel;
        private System.Windows.Forms.TextBox SearchIDBox;
        private System.Windows.Forms.DateTimePicker StartTimePicker;
        private System.Windows.Forms.Label OrLabel;
        private System.Windows.Forms.DateTimePicker EndTimePicker;
        private System.Windows.Forms.Label StartTimeLabel;
        private System.Windows.Forms.Label EndTimeLabel;
        private System.Windows.Forms.Button ClearButton2;
        private System.Windows.Forms.Button EnterButton;
        private System.Windows.Forms.Button EnterButton1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SearchID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn EndTime;
    }
}