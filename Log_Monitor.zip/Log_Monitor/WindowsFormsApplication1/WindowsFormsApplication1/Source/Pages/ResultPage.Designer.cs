﻿namespace LogMonitorApplication
{
    partial class ResultPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResultPage));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.BackButton1 = new System.Windows.Forms.Button();
            this.NumberPresentLabel = new System.Windows.Forms.Label();
            this.NumberPresentBox = new System.Windows.Forms.TextBox();
            this.WordCountLabel = new System.Windows.Forms.Label();
            this.WordCountList = new System.Windows.Forms.ListView();
            this.WordColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.CountColumn = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.NumberReadLabel = new System.Windows.Forms.Label();
            this.NumberReadBox = new System.Windows.Forms.TextBox();
            this.WordCountChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.HomeLocationLabel = new System.Windows.Forms.Label();
            this.LocationLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.WordCountChart)).BeginInit();
            this.SuspendLayout();
            // 
            // BackButton1
            // 
            this.BackButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BackButton1.BackgroundImage")));
            this.BackButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BackButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BackButton1.Location = new System.Drawing.Point(137, 627);
            this.BackButton1.Name = "BackButton1";
            this.BackButton1.Size = new System.Drawing.Size(99, 30);
            this.BackButton1.TabIndex = 0;
            this.BackButton1.UseVisualStyleBackColor = true;
            this.BackButton1.Click += new System.EventHandler(this.BackButton1_Click);
            // 
            // NumberPresentLabel
            // 
            this.NumberPresentLabel.AutoSize = true;
            this.NumberPresentLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NumberPresentLabel.Location = new System.Drawing.Point(174, 66);
            this.NumberPresentLabel.Name = "NumberPresentLabel";
            this.NumberPresentLabel.Size = new System.Drawing.Size(243, 20);
            this.NumberPresentLabel.TabIndex = 1;
            this.NumberPresentLabel.Text = "Number of Log Files in the Folder";
            this.NumberPresentLabel.Click += new System.EventHandler(this.NumberLabel_Click);
            // 
            // NumberPresentBox
            // 
            this.NumberPresentBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumberPresentBox.Location = new System.Drawing.Point(455, 66);
            this.NumberPresentBox.Name = "NumberPresentBox";
            this.NumberPresentBox.Size = new System.Drawing.Size(100, 19);
            this.NumberPresentBox.TabIndex = 2;
            this.NumberPresentBox.Text = "Value Here";
            this.NumberPresentBox.TextChanged += new System.EventHandler(this.NumberBox_TextChanged);
            // 
            // WordCountLabel
            // 
            this.WordCountLabel.AutoSize = true;
            this.WordCountLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.WordCountLabel.Location = new System.Drawing.Point(174, 175);
            this.WordCountLabel.Name = "WordCountLabel";
            this.WordCountLabel.Size = new System.Drawing.Size(243, 20);
            this.WordCountLabel.TabIndex = 3;
            this.WordCountLabel.Text = "Word Count of Custom Keywords";
            this.WordCountLabel.Click += new System.EventHandler(this.WordCountLabel_Click);
            // 
            // WordCountList
            // 
            this.WordCountList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.WordColumn,
            this.CountColumn});
            this.WordCountList.HideSelection = false;
            this.WordCountList.Location = new System.Drawing.Point(455, 175);
            this.WordCountList.Name = "WordCountList";
            this.WordCountList.Size = new System.Drawing.Size(260, 134);
            this.WordCountList.TabIndex = 6;
            this.WordCountList.UseCompatibleStateImageBehavior = false;
            this.WordCountList.View = System.Windows.Forms.View.List;
            this.WordCountList.SelectedIndexChanged += new System.EventHandler(this.WordCountList_SelectedIndexChanged);
            // 
            // WordColumn
            // 
            this.WordColumn.Text = "Word";
            this.WordColumn.Width = 128;
            // 
            // CountColumn
            // 
            this.CountColumn.Text = "Count";
            this.CountColumn.Width = 128;
            // 
            // NumberReadLabel
            // 
            this.NumberReadLabel.AutoSize = true;
            this.NumberReadLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.NumberReadLabel.Location = new System.Drawing.Point(223, 118);
            this.NumberReadLabel.Name = "NumberReadLabel";
            this.NumberReadLabel.Size = new System.Drawing.Size(194, 20);
            this.NumberReadLabel.TabIndex = 7;
            this.NumberReadLabel.Text = "Number of Log Files Read";
            this.NumberReadLabel.Click += new System.EventHandler(this.NumberReadLabel_Click);
            // 
            // NumberReadBox
            // 
            this.NumberReadBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.NumberReadBox.Location = new System.Drawing.Point(455, 118);
            this.NumberReadBox.Name = "NumberReadBox";
            this.NumberReadBox.Size = new System.Drawing.Size(100, 19);
            this.NumberReadBox.TabIndex = 8;
            this.NumberReadBox.Text = "Value Here";
            this.NumberReadBox.TextChanged += new System.EventHandler(this.NumberReadBox_TextChanged);
            // 
            // WordCountChart
            // 
            chartArea1.Name = "ChartArea1";
            this.WordCountChart.ChartAreas.Add(chartArea1);
            legend1.Alignment = System.Drawing.StringAlignment.Center;
            legend1.BorderColor = System.Drawing.Color.Transparent;
            legend1.Name = "Legend1";
            legend1.Title = "Legend";
            this.WordCountChart.Legends.Add(legend1);
            this.WordCountChart.Location = new System.Drawing.Point(178, 339);
            this.WordCountChart.Name = "WordCountChart";
            this.WordCountChart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            this.WordCountChart.Size = new System.Drawing.Size(537, 272);
            this.WordCountChart.TabIndex = 9;
            this.WordCountChart.Text = "Word Count";
            title1.Name = "WordCountChart";
            title1.Text = "Word Count";
            this.WordCountChart.Titles.Add(title1);
            this.WordCountChart.Click += new System.EventHandler(this.WordCountChart_Click);
            // 
            // HomeLocationLabel
            // 
            this.HomeLocationLabel.AutoSize = true;
            this.HomeLocationLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.HomeLocationLabel.Location = new System.Drawing.Point(451, 22);
            this.HomeLocationLabel.Name = "HomeLocationLabel";
            this.HomeLocationLabel.Size = new System.Drawing.Size(156, 20);
            this.HomeLocationLabel.TabIndex = 10;
            this.HomeLocationLabel.Text = "Home Location Here";
            // 
            // LocationLabel
            // 
            this.LocationLabel.AutoSize = true;
            this.LocationLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.LocationLabel.Location = new System.Drawing.Point(318, 22);
            this.LocationLabel.Name = "LocationLabel";
            this.LocationLabel.Size = new System.Drawing.Size(99, 20);
            this.LocationLabel.TabIndex = 11;
            this.LocationLabel.Text = "File Location";
            // 
            // ResultPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(983, 704);
            this.Controls.Add(this.LocationLabel);
            this.Controls.Add(this.HomeLocationLabel);
            this.Controls.Add(this.WordCountChart);
            this.Controls.Add(this.NumberReadBox);
            this.Controls.Add(this.NumberReadLabel);
            this.Controls.Add(this.WordCountList);
            this.Controls.Add(this.WordCountLabel);
            this.Controls.Add(this.NumberPresentBox);
            this.Controls.Add(this.NumberPresentLabel);
            this.Controls.Add(this.BackButton1);
            this.Name = "ResultPage";
            this.Text = "Query Result";
            this.Load += new System.EventHandler(this.ResultPage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.WordCountChart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton1;
        private System.Windows.Forms.Label NumberPresentLabel;
        private System.Windows.Forms.TextBox NumberPresentBox;
        private System.Windows.Forms.Label WordCountLabel;
        private System.Windows.Forms.ListView WordCountList;
        private System.Windows.Forms.ColumnHeader WordColumn;
        private System.Windows.Forms.ColumnHeader CountColumn;
        private System.Windows.Forms.Label NumberReadLabel;
        private System.Windows.Forms.TextBox NumberReadBox;
        private System.Windows.Forms.DataVisualization.Charting.Chart WordCountChart;
        private System.Windows.Forms.Label HomeLocationLabel;
        private System.Windows.Forms.Label LocationLabel;
    }
}