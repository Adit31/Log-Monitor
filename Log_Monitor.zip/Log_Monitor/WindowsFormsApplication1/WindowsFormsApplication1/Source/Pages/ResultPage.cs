﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace LogMonitorApplication
{
    public partial class ResultPage : Form
    {
        Form parent1;
        string LogFolderPath;
        string Title;
        int id;
        public ResultPage(Form Parent_form1, string path, string title)
        {
            parent1 = Parent_form1;
            LogFolderPath = path;
            Title = title;
            InitializeComponent();
            id = 0;
        }

        public void SetId(int x)
        {
            id = x;
        }

        private void ResultPage_Load(object sender, EventArgs e)
        {
            FolderAccess fa = new FolderAccess(LogFolderPath, id, Title);
            string errMsg = "";
            int res = fa.RunQuery(ref errMsg);
            if (res == 0)
            {
                string errMsg1 = "";
                int res1 = fa.FolderRead(ref errMsg1);
                if (res1 == 0)
                {
                    HomeLocationLabel.Text = fa.getHomeLocation();
                    NumberPresentBox.Text = fa.GetFilesPresent().ToString();
                    NumberReadBox.Text = fa.GetFilesRead().ToString();
                    for (int i = 0; i < fa.counter.Count; i++)
                    {
                        string entry = fa.keywords[i].ToString() + " -> " + fa.counter[i].ToString();
                        WordCountList.Items.Add(entry);
                    }
                    DrawPieChart(fa.keywords, fa.counter);
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show(errMsg1);
                }
            }
            else
                System.Windows.Forms.MessageBox.Show(errMsg);
        }

        private void BackButton1_Click(object sender, EventArgs e)
        {
            parent1.Visible = true;
            this.Close();
        }

        private void DrawPieChart(List<string> keywords, List<int> count)
        { 
            string seriesname = "WordCountValues";
            WordCountChart.Series.Add(seriesname);
            WordCountChart.Series[seriesname].ChartType = SeriesChartType.Pie;
            for (int i = 0; i < keywords.Count; i++)
            {
                WordCountChart.Series[seriesname].Points.AddXY(keywords[i], count[i]);
            }
            WordCountChart.Series[seriesname]["PieLabelStyle"] = "Disabled";
        }

        private void NumberBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void WordCountList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void NumberLabel_Click(object sender, EventArgs e)
        {

        }

        private void WordCountLabel_Click(object sender, EventArgs e)
        {

        }

        private void NumberReadBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void WordCountChart_Click(object sender, EventArgs e)
        {

        }

        private void NumberReadLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
