﻿namespace LogMonitorApplication
{
    partial class LogMonitorHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogMonitorHome));
            this.Tabs = new System.Windows.Forms.TabControl();
            this.CreatePage = new System.Windows.Forms.TabPage();
            this.LogLabel = new System.Windows.Forms.Label();
            this.LogLocationBox = new System.Windows.Forms.TextBox();
            this.CommaLabel = new System.Windows.Forms.Label();
            this.KeywordBox = new System.Windows.Forms.TextBox();
            this.ClearButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.KeywordLabel = new System.Windows.Forms.Label();
            this.LocationButton = new System.Windows.Forms.Button();
            this.LocationLabel = new System.Windows.Forms.Label();
            this.TitleLabel = new System.Windows.Forms.Label();
            this.TitleBox = new System.Windows.Forms.TextBox();
            this.OpenPage = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.LogLabel1 = new System.Windows.Forms.Label();
            this.ProjectsListBox = new System.Windows.Forms.ListBox();
            this.SearchLabel = new System.Windows.Forms.Label();
            this.ClearButton1 = new System.Windows.Forms.Button();
            this.OpenButton = new System.Windows.Forms.Button();
            this.FileTitleBox = new System.Windows.Forms.TextBox();
            this.SavedListLabel = new System.Windows.Forms.Label();
            this.LogFolderBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.Tabs.SuspendLayout();
            this.CreatePage.SuspendLayout();
            this.OpenPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tabs
            // 
            this.Tabs.Controls.Add(this.CreatePage);
            this.Tabs.Controls.Add(this.OpenPage);
            this.Tabs.ItemSize = new System.Drawing.Size(81, 45);
            this.Tabs.Location = new System.Drawing.Point(0, 0);
            this.Tabs.Name = "Tabs";
            this.Tabs.SelectedIndex = 0;
            this.Tabs.Size = new System.Drawing.Size(905, 628);
            this.Tabs.TabIndex = 1;
            // 
            // CreatePage
            // 
            this.CreatePage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("CreatePage.BackgroundImage")));
            this.CreatePage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CreatePage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CreatePage.Controls.Add(this.LogLabel);
            this.CreatePage.Controls.Add(this.LogLocationBox);
            this.CreatePage.Controls.Add(this.CommaLabel);
            this.CreatePage.Controls.Add(this.KeywordBox);
            this.CreatePage.Controls.Add(this.ClearButton);
            this.CreatePage.Controls.Add(this.SaveButton);
            this.CreatePage.Controls.Add(this.KeywordLabel);
            this.CreatePage.Controls.Add(this.LocationButton);
            this.CreatePage.Controls.Add(this.LocationLabel);
            this.CreatePage.Controls.Add(this.TitleLabel);
            this.CreatePage.Controls.Add(this.TitleBox);
            this.CreatePage.Location = new System.Drawing.Point(4, 49);
            this.CreatePage.Name = "CreatePage";
            this.CreatePage.Padding = new System.Windows.Forms.Padding(3);
            this.CreatePage.Size = new System.Drawing.Size(897, 575);
            this.CreatePage.TabIndex = 0;
            this.CreatePage.Text = "Create";
            this.CreatePage.UseVisualStyleBackColor = true;
            this.CreatePage.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // LogLabel
            // 
            this.LogLabel.AutoSize = true;
            this.LogLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogLabel.ForeColor = System.Drawing.SystemColors.GrayText;
            this.LogLabel.Location = new System.Drawing.Point(406, 24);
            this.LogLabel.Name = "LogLabel";
            this.LogLabel.Size = new System.Drawing.Size(126, 25);
            this.LogLabel.TabIndex = 1;
            this.LogLabel.Text = "Log Monitor";
            // 
            // LogLocationBox
            // 
            this.LogLocationBox.Location = new System.Drawing.Point(584, 188);
            this.LogLocationBox.Name = "LogLocationBox";
            this.LogLocationBox.Size = new System.Drawing.Size(268, 26);
            this.LogLocationBox.TabIndex = 13;
            this.LogLocationBox.TextChanged += new System.EventHandler(this.LocationBox_TextChanged);
            // 
            // CommaLabel
            // 
            this.CommaLabel.AutoSize = true;
            this.CommaLabel.Location = new System.Drawing.Point(488, 320);
            this.CommaLabel.Name = "CommaLabel";
            this.CommaLabel.Size = new System.Drawing.Size(255, 20);
            this.CommaLabel.TabIndex = 12;
            this.CommaLabel.Text = "Comma Seperated Values (upto 6)\r\n";
            this.CommaLabel.Click += new System.EventHandler(this.CommaLabel_Click);
            // 
            // KeywordBox
            // 
            this.KeywordBox.Location = new System.Drawing.Point(424, 273);
            this.KeywordBox.MaxLength = 200;
            this.KeywordBox.Name = "KeywordBox";
            this.KeywordBox.Size = new System.Drawing.Size(428, 26);
            this.KeywordBox.TabIndex = 11;
            this.KeywordBox.TextChanged += new System.EventHandler(this.KeywordBox_TextChanged);
            // 
            // ClearButton
            // 
            this.ClearButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ClearButton.BackgroundImage")));
            this.ClearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClearButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ClearButton.Location = new System.Drawing.Point(492, 449);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(99, 30);
            this.ClearButton.TabIndex = 10;
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SaveButton.BackgroundImage")));
            this.SaveButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.SaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SaveButton.Location = new System.Drawing.Point(365, 449);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(97, 30);
            this.SaveButton.TabIndex = 9;
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.CreateButton_Click);
            // 
            // KeywordLabel
            // 
            this.KeywordLabel.AutoSize = true;
            this.KeywordLabel.Location = new System.Drawing.Point(143, 276);
            this.KeywordLabel.Name = "KeywordLabel";
            this.KeywordLabel.Size = new System.Drawing.Size(179, 20);
            this.KeywordLabel.TabIndex = 8;
            this.KeywordLabel.Text = "Enter Custom Keywords";
            // 
            // LocationButton
            // 
            this.LocationButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("LocationButton.BackgroundImage")));
            this.LocationButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LocationButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LocationButton.Location = new System.Drawing.Point(424, 191);
            this.LocationButton.Name = "LocationButton";
            this.LocationButton.Size = new System.Drawing.Size(108, 26);
            this.LocationButton.TabIndex = 1;
            this.LocationButton.UseVisualStyleBackColor = true;
            this.LocationButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // LocationLabel
            // 
            this.LocationLabel.AutoSize = true;
            this.LocationLabel.Location = new System.Drawing.Point(158, 191);
            this.LocationLabel.Name = "LocationLabel";
            this.LocationLabel.Size = new System.Drawing.Size(164, 20);
            this.LocationLabel.TabIndex = 2;
            this.LocationLabel.Text = "Choose  Log Location";
            // 
            // TitleLabel
            // 
            this.TitleLabel.AutoSize = true;
            this.TitleLabel.Location = new System.Drawing.Point(231, 123);
            this.TitleLabel.Name = "TitleLabel";
            this.TitleLabel.Size = new System.Drawing.Size(91, 20);
            this.TitleLabel.TabIndex = 1;
            this.TitleLabel.Text = "Project Title";
            // 
            // TitleBox
            // 
            this.TitleBox.Location = new System.Drawing.Point(424, 120);
            this.TitleBox.MaxLength = 150;
            this.TitleBox.Name = "TitleBox";
            this.TitleBox.Size = new System.Drawing.Size(428, 26);
            this.TitleBox.TabIndex = 0;
            this.TitleBox.TextChanged += new System.EventHandler(this.TitleBox_TextChanged);
            // 
            // OpenPage
            // 
            this.OpenPage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenPage.BackgroundImage")));
            this.OpenPage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.OpenPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.OpenPage.Controls.Add(this.label1);
            this.OpenPage.Controls.Add(this.DeleteButton);
            this.OpenPage.Controls.Add(this.LogLabel1);
            this.OpenPage.Controls.Add(this.ProjectsListBox);
            this.OpenPage.Controls.Add(this.SearchLabel);
            this.OpenPage.Controls.Add(this.ClearButton1);
            this.OpenPage.Controls.Add(this.OpenButton);
            this.OpenPage.Controls.Add(this.FileTitleBox);
            this.OpenPage.Controls.Add(this.SavedListLabel);
            this.OpenPage.Location = new System.Drawing.Point(4, 49);
            this.OpenPage.Name = "OpenPage";
            this.OpenPage.Padding = new System.Windows.Forms.Padding(3);
            this.OpenPage.Size = new System.Drawing.Size(897, 575);
            this.OpenPage.TabIndex = 1;
            this.OpenPage.Text = "Open";
            this.OpenPage.UseVisualStyleBackColor = true;
            this.OpenPage.Click += new System.EventHandler(this.OpenPage_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(546, 506);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "To Delete";
            // 
            // DeleteButton
            // 
            this.DeleteButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DeleteButton.BackgroundImage")));
            this.DeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DeleteButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.DeleteButton.Location = new System.Drawing.Point(647, 502);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(103, 29);
            this.DeleteButton.TabIndex = 9;
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // LogLabel1
            // 
            this.LogLabel1.AutoSize = true;
            this.LogLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogLabel1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.LogLabel1.Location = new System.Drawing.Point(372, 29);
            this.LogLabel1.Name = "LogLabel1";
            this.LogLabel1.Size = new System.Drawing.Size(126, 25);
            this.LogLabel1.TabIndex = 8;
            this.LogLabel1.Text = "Log Monitor";
            // 
            // ProjectsListBox
            // 
            this.ProjectsListBox.FormattingEnabled = true;
            this.ProjectsListBox.ItemHeight = 20;
            this.ProjectsListBox.Location = new System.Drawing.Point(449, 138);
            this.ProjectsListBox.Name = "ProjectsListBox";
            this.ProjectsListBox.Size = new System.Drawing.Size(192, 144);
            this.ProjectsListBox.Sorted = true;
            this.ProjectsListBox.TabIndex = 7;
            this.ProjectsListBox.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged_1);
            // 
            // SearchLabel
            // 
            this.SearchLabel.AutoSize = true;
            this.SearchLabel.Location = new System.Drawing.Point(160, 372);
            this.SearchLabel.Name = "SearchLabel";
            this.SearchLabel.Size = new System.Drawing.Size(196, 20);
            this.SearchLabel.TabIndex = 6;
            this.SearchLabel.Text = "Enter Title from above only";
            // 
            // ClearButton1
            // 
            this.ClearButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ClearButton1.BackgroundImage")));
            this.ClearButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClearButton1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ClearButton1.Location = new System.Drawing.Point(464, 442);
            this.ClearButton1.Name = "ClearButton1";
            this.ClearButton1.Size = new System.Drawing.Size(103, 29);
            this.ClearButton1.TabIndex = 4;
            this.ClearButton1.UseVisualStyleBackColor = true;
            this.ClearButton1.Click += new System.EventHandler(this.button2_Click);
            // 
            // OpenButton
            // 
            this.OpenButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OpenButton.BackgroundImage")));
            this.OpenButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.OpenButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OpenButton.Location = new System.Drawing.Point(336, 442);
            this.OpenButton.Name = "OpenButton";
            this.OpenButton.Size = new System.Drawing.Size(103, 29);
            this.OpenButton.TabIndex = 3;
            this.OpenButton.UseVisualStyleBackColor = true;
            this.OpenButton.Click += new System.EventHandler(this.OpenButton_Click);
            // 
            // FileTitleBox
            // 
            this.FileTitleBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.FileTitleBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.HistoryList;
            this.FileTitleBox.Location = new System.Drawing.Point(449, 369);
            this.FileTitleBox.MaxLength = 150;
            this.FileTitleBox.Name = "FileTitleBox";
            this.FileTitleBox.Size = new System.Drawing.Size(352, 26);
            this.FileTitleBox.TabIndex = 2;
            this.FileTitleBox.TextChanged += new System.EventHandler(this.FileLocationBox_TextChanged);
            // 
            // SavedListLabel
            // 
            this.SavedListLabel.AutoSize = true;
            this.SavedListLabel.Location = new System.Drawing.Point(160, 170);
            this.SavedListLabel.Name = "SavedListLabel";
            this.SavedListLabel.Size = new System.Drawing.Size(115, 20);
            this.SavedListLabel.TabIndex = 0;
            this.SavedListLabel.Text = "Saved Projects";
            this.SavedListLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // LogMonitorHome
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(905, 626);
            this.Controls.Add(this.Tabs);
            this.Name = "LogMonitorHome";
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Tabs.ResumeLayout(false);
            this.CreatePage.ResumeLayout(false);
            this.CreatePage.PerformLayout();
            this.OpenPage.ResumeLayout(false);
            this.OpenPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl Tabs;
        private System.Windows.Forms.TabPage CreatePage;
        private System.Windows.Forms.TabPage OpenPage;
        private System.Windows.Forms.Label LocationLabel;
        private System.Windows.Forms.Label TitleLabel;
        private System.Windows.Forms.TextBox TitleBox;
        private System.Windows.Forms.Button LocationButton;
        private System.Windows.Forms.Label KeywordLabel;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Label CommaLabel;
        private System.Windows.Forms.TextBox KeywordBox;
        private System.Windows.Forms.TextBox LogLocationBox;
        private System.Windows.Forms.Label SavedListLabel;
        private System.Windows.Forms.Button ClearButton1;
        private System.Windows.Forms.Button OpenButton;
        private System.Windows.Forms.Label SearchLabel;
        private System.Windows.Forms.TextBox FileTitleBox;
        private System.Windows.Forms.ListBox ProjectsListBox;
        private System.Windows.Forms.Label LogLabel;
        private System.Windows.Forms.Label LogLabel1;
        private System.Windows.Forms.FolderBrowserDialog LogFolderBrowser;
        private System.Windows.Forms.Button DeleteButton;
        private System.Windows.Forms.Label label1;
    }
}

