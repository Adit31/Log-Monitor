﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace LogMonitorApplication
{
    public partial class LogMonitorHome : Form
    {

        ProjectDetails projlistobj;
        public LogMonitorHome()
        {
            InitializeComponent();
            init();
            AutoDelete AutoDelObj = new AutoDelete();
            Tabs.SelectedIndexChanged += Tabs_SelectedIndexChanged;
        }

        void init()
        {
            string errMsg="";
            try
            {
                ProjectsListBox.Items.Clear();
                projlistobj = new ProjectDetails();
                int res = projlistobj.createProjectList(ref errMsg);
                if (res == 0)
                {
                    Dictionary<int, string> dict = projlistobj.GetTitleList();
                    foreach (KeyValuePair<int, string> item in dict)
                    {
                        ProjectsListBox.Items.Add(item.Value);
                    }
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show(errMsg);
                }
            }
            catch
            {
                System.Windows.Forms.MessageBox.Show("Configuration error");
            } 
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            if (LogFolderBrowser.ShowDialog() == DialogResult.OK)
            {
                LogLocationBox.Text = LogFolderBrowser.SelectedPath;
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            TitleBox.Clear();
            KeywordBox.Clear();
            LogLocationBox.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileTitleBox.Clear();
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            string errMsg = "";
            if (TitleBox.Text == "" || LogLocationBox.Text == "" || KeywordBox.Text == "")
                System.Windows.Forms.MessageBox.Show("Null values not valid");
            else if (Directory.Exists(LogLocationBox.Text) == false)
                System.Windows.Forms.MessageBox.Show("Folder Path Mentioned does not Exist");
            else
            {
                int res = projlistobj.createNewProject(TitleBox.Text, LogLocationBox.Text, KeywordBox.Text, ref errMsg);
                if (res != 0)
                {
                    System.Windows.Forms.MessageBox.Show(errMsg);
                }

                else
                {
                    System.Windows.Forms.MessageBox.Show("Project Created Successfully");
                }
            } 
        }

        private void OpenButton_Click(object sender, EventArgs e)
        {
            if (FileTitleBox.Text == "")
                System.Windows.Forms.MessageBox.Show("Please Select one Project Title from Above");
            else
            {
                string selected = FileTitleBox.Text;
                SearchProjectDetails proObj = projlistobj.getProject(selected);
                if (ProjectsListBox.Items.Contains(selected) == true)
                {
                    ProjectPage f1 = new ProjectPage(this, ref proObj);
                    f1.Show();
                    this.Visible = false;
                }
                else
                    System.Windows.Forms.MessageBox.Show("Enter a Title from Above Only");
            }
        }

        private void Tabs_SelectedIndexChanged(Object sender, EventArgs e)
        {
            switch ((sender as TabControl).SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    this.init();
                    break;
            }
        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            FileTitleBox.Text = ProjectsListBox.GetItemText(ProjectsListBox.SelectedItem);
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            string errMsg = "";
            if (FileTitleBox.Text == "")
                System.Windows.Forms.MessageBox.Show("Select a Title First");
            else
            {
                int res = projlistobj.DeleteRecord(FileTitleBox.Text, ref errMsg);
                if (res == -1)
                    System.Windows.Forms.MessageBox.Show(errMsg);
                else if (res > 0)
                {
                    System.Windows.Forms.MessageBox.Show("Deleted Successfully");
                    this.init();
                }
                else if (res == 0)
                    System.Windows.Forms.MessageBox.Show("Select a Project Title from Above");
            }
        }

        private void LastReadLogLabel_Click(object sender, EventArgs e)
        {
         
        }

        private void TimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DateLabel_Click(object sender, EventArgs e)
        {

        }

        private void OpenPage_Click(object sender, EventArgs e)
        {

        }

        private void LocationBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void TitleBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void KeywordBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SearchFileButton_Click(object sender, EventArgs e)
        {

        }

        private void FileLocationBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void folderBrowserDialog1_HelpRequest_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void CommaLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
